package com.shanjupay.common.domain;

public interface ErrorCode {

    int getCode();

    String getDesc();

}
